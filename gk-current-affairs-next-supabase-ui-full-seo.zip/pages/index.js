export default function Home() {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center text-white"
      style={{
        backgroundImage: "url('/background.png')",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <header className="text-center py-6 bg-black/50 rounded-xl p-4">
        <img src="/logo.png" alt="App Logo" className="w-20 mx-auto mb-3" />
        <h1 className="text-3xl font-bold">GK & Current Affairs Quiz</h1>
        <p className="text-gray-300 mt-2">
          Stay updated with weekly quizzes and AI-powered Q&A
        </p>
      </header>

      <main className="flex flex-col gap-6 w-full max-w-lg p-6 bg-black/60 rounded-2xl shadow-xl backdrop-blur-lg mt-6">
        {/* Quiz + AI Question Components */}
      </main>

      <footer className="mt-10 text-gray-300 text-sm">
        © {new Date().getFullYear()} GK Quiz App — All rights reserved.
      </footer>
    </div>
  );
}
