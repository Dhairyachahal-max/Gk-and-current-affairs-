import { Html, Head, Main, NextScript } from 'next/document';

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        <meta
          name="description"
          content="AI-powered GK & Current Affairs Quiz App. Test your knowledge, stay updated, and get weekly reminders."
        />
        <meta property="og:title" content="GK & Current Affairs App" />
        <meta
          property="og:description"
          content="Weekly GK quizzes and AI-powered Q&A to stay updated."
        />
        <meta property="og:image" content="/logo.png" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://yourapp.vercel.app" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="GK & Current Affairs App" />
        <meta
          name="twitter:description"
          content="Stay updated with GK and Current Affairs quizzes + AI answers."
        />
        <meta name="twitter:image" content="/logo.png" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
